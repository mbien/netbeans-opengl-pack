package demos.nehe.lesson33;

class TGAHeader {
    byte[] Header = new byte[12];									// TGA File Header
}
