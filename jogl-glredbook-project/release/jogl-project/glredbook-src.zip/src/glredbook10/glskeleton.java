package glredbook10;


import com.sun.opengl.util.FPSAnimator;
import javax.media.opengl.*;
import javax.media.opengl.awt.GLCanvas;
import javax.media.opengl.awt.GLJPanel;

public abstract class glskeleton //
// implements //
// KeyListener//
// , MouseListener//
// , MouseMotionListener//
// , MouseWheelListener //
// Runnable //
{
    protected GLJPanel jcanvas;
    protected GLCanvas canvas;

    protected FPSAnimator animator;
    protected int FramePerSecond = 24;

    /**
     * Constructs an instance of this object and also set its canvas reference
     * to be a GLJPanel.
     * 
     * @param jcanvas
     */
    public glskeleton(GLJPanel jcanvas) {
        this();
        this.jcanvas = jcanvas;
    }

    /**
     * Constructs an instance of this object and also set its canvas reference
     * to be a GLCanvas.
     * 
     * @param jcanvas
     */
    public glskeleton(GLCanvas canvas) {
        this();
        this.canvas = canvas;
    }

    /**
     * Construct a default instance without specifying a type of canvas
     * reference. <br />
     * <br />
     * NOTE: <br />
     * When constructing an object this way, make sure to use
     * <code>setCanvas()</code> later to reference the canvas. Otherwise, a
     * GLException is thrown.
     */
    public glskeleton() {
    }

    public final void setCanvas(GLJPanel jcanvas) {
        this.jcanvas = jcanvas;
    }

    public final void setCanvas(GLCanvas canvas) {
        this.canvas = canvas;
    }

    /**
     * Call the reference canvas's display methods. Should be called after
     * handling of input events.
     */
    public final void refresh() {
        if (jcanvas == null && canvas == null)
            throw new GLException//
            ("Either reference to GLJPanel or GLCanvas is not set.");
        if (jcanvas != null)
            jcanvas.display();
        if (canvas != null)
            canvas.display();
    }//

    /**
     * Set or reset the canvas's animator.
     * 
     * @param animator
     */
    public final void setAnimator(FPSAnimator animator) {
        this.animator = animator;
    }//

    public final void runExit() {
        new Thread(new Runnable() {
            public void run() {
                animator.stop();
                System.exit(0);
            }
        }).start();

    }//

}//
