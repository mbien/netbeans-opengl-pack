Note: the inclusion of these pre-built jar files is to facilitate the
building of the GearsJOALApplet example.
