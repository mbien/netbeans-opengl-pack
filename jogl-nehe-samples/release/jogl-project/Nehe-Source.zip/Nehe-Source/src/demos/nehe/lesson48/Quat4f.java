package demos.nehe.lesson48;

/**
 * Created by IntelliJ IDEA.
 * User: pepijn
 * Date: Aug 7, 2005
 * Time: 5:50:25 PM
 * To change this template use File | Settings | File Templates.
 */
class Quat4f {
    public float x, y, z, w;
}
