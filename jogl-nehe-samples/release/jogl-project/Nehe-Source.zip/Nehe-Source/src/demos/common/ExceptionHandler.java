package demos.common;

/**
 * @author Pepijn Van Eeckhoudt
 */
public interface ExceptionHandler {
    void handleException(Exception e);
}
