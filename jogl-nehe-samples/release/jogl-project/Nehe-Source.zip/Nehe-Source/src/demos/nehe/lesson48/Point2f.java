package demos.nehe.lesson48;

/**
 * Created by IntelliJ IDEA.
 * User: pepijn
 * Date: Aug 7, 2005
 * Time: 5:46:24 PM
 * To change this template use File | Settings | File Templates.
 */
class Point2f {
    public float x, y;

    public Point2f(float x, float y) {
        this.x = x;
        this.y = y;
    }
}
